package com.iuni.dp.mq.weixinmsg;


/*
 * @(#)Consumer.java 2012-2-29
 *
 * Copyright 2012 SH-BBMF,Inc. All rights reserved.
 */


/**
 * 标记接口
 * @author ZuoChangjun 2012-2-29
 */
public interface Consumer {

	/**
	 * 接收消息
	 */
	//public abstract void receive(Object obj);
}
