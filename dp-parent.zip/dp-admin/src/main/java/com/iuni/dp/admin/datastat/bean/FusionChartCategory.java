package com.iuni.dp.admin.datastat.bean;

/**
 * @ClassName FusionChartCategory
 * @author CaiKe
 * @version dp-admin-1.0.0
 */
public class FusionChartCategory {
	
	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "FusionChartCategory [category=" + category + "]";
	} 
	
}
