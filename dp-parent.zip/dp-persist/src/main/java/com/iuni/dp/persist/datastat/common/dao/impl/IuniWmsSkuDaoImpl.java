package com.iuni.dp.persist.datastat.common.dao.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.iuni.dp.persist.common.dao.impl.BaseDaoImpl;
import com.iuni.dp.persist.datastat.common.dao.IuniWmsSkuDao;
import com.iuni.dp.persist.datastat.common.model.IuniWmsSku;

@Repository("iuniWmsSkuDao")
public class IuniWmsSkuDaoImpl extends BaseDaoImpl<IuniWmsSku, Serializable> implements IuniWmsSkuDao {

	private static final String SQL_MAP_NAMESPACE = "IuniWmsSku";
	@Override
	public List<Map<String, Object>> selectIuniWmsSku(Map<String,Object> params) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		list = findAllObjectsByPage2(SQL_MAP_NAMESPACE+"."+"selectIuniWmsSku", params);
		return list;
	}
	


}
