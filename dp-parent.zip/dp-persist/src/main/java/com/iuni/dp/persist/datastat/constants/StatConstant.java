package com.iuni.dp.persist.datastat.constants;

/**
 * dp-persist的datastat.stat模块常量
 * @author CaiKe
 * @version dp-admin-1.0.0
 */
public interface StatConstant {
	
	//微信图片服务器
  	public final static String WEIXIN_IMG_URL = "ias.weixin.img.url";

}
